package expedition.game_tools.character_tools;

import expedition.game_tools.character_tools.Character.Stat;
import java.util.Random;

public enum Race {
    //name, int, agi, str, max age, strong stat, weak stat, spi
    HUMAN("Human", 80, Stat.INT, Stat.None, 7),
    ELF("Elf", 120, Stat.SPI, Stat.INT, 8),
    DWARF("Dwarf", 150, Stat.STR, Stat.AGI, 7),
    OGRE("Ogre", 90, Stat.STR, Stat.AGI, 6),
    ORC("Orc", 70, Stat.AGI, Stat.INT, 6),
    HALFLING("Halfling", 100, Stat.SPI, Stat.STR, 4);

    private static final int numPlayableRaces = 4;

    private final String name;
    private final int maxLifespan;
    private final Stat strongStat;
    private final Stat weakStat;

    Race(String name, int maxLifespan, Stat strongStat, Stat weakStat, int averageSpi) {
        this.name = name;
        this.maxLifespan = maxLifespan;
        this.strongStat = strongStat;
        this.weakStat = weakStat;
    }

    public String getName() {
        return name;
    }

    public String toString() {
        return getName();
    }

    public int getAverageStat(Stat in) {
        if (in != null) {
            switch (this) {
                case HUMAN:
                    switch(in) {
                        case STR: return 20;
                        case AGI: return 20;
                        case INT: return 30;
                        case SPI: return 20;
                        case SPD: return 20;
                    }
                case ELF:
                    switch(in) {
                        case STR: return 20;
                        case AGI: return 25;
                        case INT: return 15;
                        case SPI: return 25;
                        case SPD: return 25;
                    }
                case DWARF:
                    switch(in) {
                        case STR: return 30;
                        case AGI: return 15;
                        case INT: return 27;
                        case SPI: return 20;
                        case SPD: return 18;
                    }
                case OGRE:
                    switch(in) {
                        case STR: return 45;
                        case AGI: return 15;
                        case INT: return 10;
                        case SPI: return 25;
                        case SPD: return 15;
                    }
                case ORC:
                    switch(in) {
                        case STR: return 35;
                        case AGI: return 20;
                        case INT: return 15;
                        case SPI: return 20;
                        case SPD: return 20;
                    }
                case HALFLING:
                    switch(in) {
                        case STR: return 15;
                        case AGI: return 30;
                        case INT: return 25;
                        case SPI: return 25;
                        case SPD: return 15;
                    }
                default : return 0;
            }
        } else {
            return -1;
        }
    }

    public int getMaxLifespan() {
        return maxLifespan;
    }

    public static Race randomPlayableRace() {
        Random rand = new Random();
        switch (rand.nextInt(10)) {
            case 0:
            case 1:
            case 2:
            case 3:
            case 4:
            case 5:
                return Race.HUMAN;
            case 6:
                return Race.HALFLING;
            case 7:
            case 8:
                return Race.DWARF;
            case 9:
                return Race.ELF;
            default:
                return Race.HUMAN;
        }
    }

}
