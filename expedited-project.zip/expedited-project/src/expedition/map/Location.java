package expedition.map;

import expedition.game_elements.Environment.Biome;
import expedition.game_elements.Event;

public class Location {

    public Location[] getConnections(){
        return null;
    }
    
    public Biome getBiome(){
        return null;
    }

}
    /*public enum LocationType {
        OLDRUINS("bunch of old ruins", new Biome[]{Biome.Grasslands, Biome.Mountains, Biome.Desert, Biome.Woodlands, Biome.Tundra}),
        ROADSIDECAMP("roadside camp", new Biome[]{Biome.Grasslands, Biome.Mountains, Biome.Desert, Biome.Woodlands, Biome.Tundra}),
        DESERTTEMPLE("desert temple", new Biome[]{Biome.Desert}),
        MOUNTAINSHRINE("mountain shrine", new Biome[]{Biome.Mountains}),
        TRAVELERSINN("traveler's inn", new Biome[]{Biome.Grasslands, Biome.Woodlands});

        private String name;
        
        private Biome[] biomes;

        LocationType(String name, Biome[] biomes) {
            this.name = name;
            this.biomes = biomes;
        }

        public String toString() {
            return this.name;
        }
    }*/

