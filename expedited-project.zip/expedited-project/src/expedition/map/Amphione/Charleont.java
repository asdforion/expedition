/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package expedition.map.Amphione;

import expedition.game_elements.Environment;
import expedition.game_elements.Environment.Biome;
import expedition.map.Location;

/**
 *
 * @author J76785
 */
public class Charleont extends Location{

    @Override
    public Location[] getConnections() {
        
    }

    @Override
    public Environment.Biome getBiome() {
        return Biome.City;
    }
    
}
