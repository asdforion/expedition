package expedition.game_elements;

import expedition.map.Location.LocationType;

public class Event {

    Event next;

    Event(Event next) {
        this.next = next;
    }

    enum EventType {

        TRAVELINGSALESMAN(new LocationType[]{LocationType.DESERTTEMPLE});

        LocationType[] locs; //possible locations

        EventType(LocationType[] locs) {
            this.locs = locs;
        }

    }
    
}
