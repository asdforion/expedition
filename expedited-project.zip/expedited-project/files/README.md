# expedition
A console-based caravan management simulator with a flair for adventure!
