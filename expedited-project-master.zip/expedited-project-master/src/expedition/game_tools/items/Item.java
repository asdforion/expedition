package expedition.game_tools.items;

import expedition.game_tools.StatusEffect;
import expedition.game_tools.StatusEffect.Effect;
import java.util.ArrayList;

public enum Item {

    // <editor-fold defaultstate="collapsed" desc="all items">
    //currency
    Ducat("ducat", 300, ItemType.Currency, 0, 0), //gold piece \doo-cat\
    Silleon("silleon", 20, ItemType.Currency, 0, 1), //silver piece \sill-ay-en\
    Peant("peant", 1, ItemType.Currency, 0, 2), //nickel piece \pay-ant\
    //goods
    Wax("wax", 10, ItemType.Goods, 8, 3),
    Wood("wood", 10, ItemType.Goods, 10, 4),
    //consumables
    Milk("gallon of milk", 8, ItemType.Consumable, 10, 5),
    Wine_Peach("bottle of peach wine", 25, ItemType.Consumable, 10, 6),
    Bread("loaf of bread", 5, ItemType.Consumable, 3, 7),
    //trinkets
    Necklace_Ivory("ivory necklace", 30, ItemType.Trinket, 0, 8),
    Necklace_Sapphire("sapphire necklace", 75, ItemType.Trinket, 0, 12),
    //armors
    Cuirass_Bronze("bronze cuirass", 150, ItemType.Armor, 60, 9),
    //weapons
    Sword_Bronze("bronze shortsword", 90, ItemType.Weapon, 19, 10),
    Sword_Steel("steel shortsword", 90, ItemType.Weapon, 15, 11);
    // </editor-fold>

    private final String name;
    private final int value;
    private final ItemType type;
    private final int weight;
    private final int id;

    public static final int lastID = Item.values().length - 1;

    public enum ItemType {
        Currency,
        Weapon,
        Armor,
        Trinket,
        Consumable,
        Goods;

    }

    Item(String name, int value, ItemType type, int weight, int id) {
        this.name = name;
        this.value = value;
        this.type = type;
        this.weight = weight;
        this.id = id;
    }

    public String toString() {
        return getName();
    }

    public String getName() {
        return name;
    }

    public int getValue() {
        return value;
    }

    public ItemType getType() {
        return type;
    }

    public int getWeight() {
        return weight;
    }

    public int getID() {
        return id;
    }

    public static Item parseID(int in) {
        for (Item i : Item.values()) {
            if (i.getID() == in) {
                return i;
            }
        }
        return null;
    }

    public static Item parseName(String in) {
        in = in.toLowerCase();
        for (Item i : Item.values()) {
            if (i.getName().equals(in)) {
                return i;
            }
        }
        return null;
    }

    public ArrayList<StatusEffect> getEffects() {
        ArrayList<StatusEffect> effs = new ArrayList<>();

        switch (this) {
            case Necklace_Sapphire:
                effs.add(new StatusEffect("[sapphire necklace]", "Aura of Intelligence : +2 Intelligence.", Effect.INTFLAT, -1, 2, null, false, false));
                break;
            case Cuirass_Bronze:
                effs.add(new StatusEffect("[bronze cuirass]", "Armored : -1 Damage from every attack.", Effect.DAMAGETAKENFLAT, -1, -1, null, false, false));
                effs.add(new StatusEffect("[bronze cuirass]", "Shock Absorption : -10% Damage from every attack.", Effect.DAMAGETAKENPERCENT, -1, 0.9, null, false, false));
                break;
            case Sword_Bronze:
                effs.add(new StatusEffect("[bronze shortsword]", "Heavy Sword : +3 Damage to every physical attack made.", Effect.PHYSDAMAGEDONEFLAT, -1, 3, null, false, false));
                break;
            case Sword_Steel:
                effs.add(new StatusEffect("[steel shortsword]", "Sharp Sword : +20% Damage to every physical attack made.", Effect.PHYSDAMAGEDONEPERCENT, -1, 1.2, null, false, false));
                break;
        }

        return effs;
    }

}
