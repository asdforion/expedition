package expedition.game_tools;

import static expedition.Expedition.*;
import static expedition.Other.*;
import expedition.game_tools.character_tools.Team;
import expedition.game_tools.character_tools.Character;
import expedition.game_tools.items.Item;
import java.util.ArrayList;
import java.util.Scanner;

public class Encounter {

    private final Team player;
    private final Team other;
    private ArrayList<Character> temp;
    private ArrayList<Character> playOrder;
    private Character currentChar;
    private final int padding = 20;
    private Scanner scan;

    public Encounter(Team player, Team other, Scanner scan) throws InterruptedException {
        this.player = player;
        this.other = other;
        this.scan = scan;
        if (other.size() > 0 && player.size() > 0) {
            playOrder = new ArrayList<>();
            temp = new ArrayList<>();
            for (Character x : player.list()) {
                playOrder.add(x);
            }
            for (Character x : other.list()) {
                playOrder.add(x);
            }
            fight();
        }
    }

    public void fight() throws InterruptedException {
        tprintln("Encounter: " + player.getName() + " v.s. " + other.getName() + ".");
        while (playable()) { // while both teams have surviving players.

            while (playOrder.size() > 0 && playable()) { // Action round.
                speedSort(playOrder); // Sort remaining players by speed.

                // Pop the quickest player in the round and add them to the post-queue
                currentChar = playOrder.remove(0);
                temp.add(currentChar);
                // If they're dead, skip the action.
                if (currentChar.isFallen()) {
                    continue;
                }
                // Let that character act.
                act(currentChar, player.contains(currentChar));

            }
            System.out.println("Round finished! ");

        } // a team ran out of surviving players.
    }

    public void act(Character c, Boolean player) throws InterruptedException {
        if (player) {
            // player action
            playerMenu();
            tprintln("YOU: " + c.getName() + "'s turn! They have " + c.getSpeed() + " speed.");
        } else {
            // ai action
            tprintln("AI : " + c.getName() + "'s turn! They have " + c.getSpeed() + " speed.");
        }
    }

    public void playerMenu() throws InterruptedException {
        String in;
        int intIn;
        boolean menu = true;
        while (menu) { // t | p | s | q | d | i
            print("\n---\n");
            in = input(scan).toLowerCase();
            if (in.matches("^\\?|help$")) {
                printHelp();
            } else if (in.matches("^(unequip(\\s+)(\\d+)(\\s+)(.+))$")) {
            } else {
                print("\n");
                printTab();
                println("Your input was misunderstood. Type >? or >help to view the manual.");
            }
        }
    }

    public void printHelp() {

    }
    
    public void printFight(Character current) {
        int iter = 1;
        ArrayList<Character> comboOrder = new ArrayList<>();
        speedSort(playOrder);
        for(Character p : playOrder){
            comboOrder.add(p);
        }
        for(Character p : temp){
            comboOrder.add(p);
        }
        
        for(Character p : player.list()){
            tprintln(p.getName() + " - Level " + p.getLevel() + " " + p.getType());
            tprintln("    Health: " + p.getHealthCurr() + "/"+ p.getHealthMax() + " | Energy: " + p.getEnergyCurr() + "/" + p.getEnergyMax() + "");
        }
        for(Character p : other.list()){
            tprintln("");
        }
    }

    public boolean playable() {
        return player.hasConsciousMembers() && other.hasConsciousMembers();
    }

    public static void speedSort(ArrayList<Character> arr) {
        int n = arr.size();
        int k;
        for (int m = n; m >= 0; m--) {
            for (int i = 0; i < n - 1; i++) {
                k = i + 1;
                if (arr.get(i).getSpeed() < arr.get(k).getSpeed()) {
                    swapIndex(i, k, arr);
                }
            }
        }
    }

    public static void swapIndex(int i, int j, ArrayList<Character> arr) {
        Character c;
        c = arr.get(i);
        arr.set(i, arr.get(j));
        arr.set(j, c);
    }

}
